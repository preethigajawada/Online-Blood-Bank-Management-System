import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LogOutProc extends HttpServlet
{
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
    {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            
            request.getSession().invalidate();
            
            out.println("<h3>Logged Out Successfully</h3>");
            request.getRequestDispatcher("SignIn.html").include(request, response);
            
            
            out.close();
    }
}