/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SDBBGProc")
public class SDBBGProc extends HttpServlet 
{
        protected void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
         {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            
            String bg=request.getParameter("bg");
            String url="jdbc:mysql://localhost:3306/obbs",user="Anirudh",pwd="OBBS@123@";
                
            int i=1,j=1;
            try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection conn=DriverManager.getConnection(url, user, pwd);
                    Statement stmt=conn.createStatement();
                    String query="SELECT * FROM donors where Blood_Group='"+bg+"' ";
                    ResultSet rs=stmt.executeQuery(query);
                    
                    out.println("<body><center>");
                    out.println("<h1>Donors</h1><br>");
                    out.println("<table border=1 width=50% height=50%>");  
                    out.println("<tr><th>S.No</th><th>Name</th><th>Email</th><th>City</th><th>Blood Group</th><th>Last Donation Date</th><th>Gender</th><th>Contact Number</th><tr>");  
                    
                    while(rs.next())
                    {
                       out.println("<tr><td>" + i + "</td><td>" + rs.getString(1) + "</td><td>" + rs.getString(2) + "</td><td>" + rs.getString(3) + "</td><td>" + rs.getString(4) + "</td><td>" + rs.getString(5) + "</td><td>" + rs.getString(6) + "</td><td>" + rs.getString(7) + "</td></tr>");
                       i=i+1;
                    }
                    out.println("</table>");  
                    out.println("</center></body>");
                    out.println("<br><br><br>");
                    
                    
                    String query1="SELECT * FROM organisations ";
                    ResultSet rs1=stmt.executeQuery(query1);                    
                     out.println("<body><center>");
                    out.println("<h1>Organisations</h1><br>");
                    out.println("<table border=1");  
                    out.println("<tr><th>S.No</th><th>Organisation Name</th><th>City</th><th>Contact Number</th><th>Email</th><tr>");  
                    
                    while(rs1.next())
                    {
                       out.println("<tr><td>" + j + "</td><td>" + rs1.getString(1) + "</td><td>" + rs1.getString(2) + "</td><td>" + rs1.getString(3) + "</td><td>" + rs1.getString(4) + "</td></tr>");
                       j=j+1;
                    }
                    out.println("</table>");  
                    out.println("</center></body>");
                    out.println("<br><br><br>");
                }catch(Exception e){}
            out.close();
         }
        protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
        {
            doGet(request,response);
        }
}