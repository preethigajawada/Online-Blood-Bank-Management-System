import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CPWD extends HttpServlet
{
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
    {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            
            HttpSession session=request.getSession(false);
            String uname=(String)session.getAttribute("username");
            
            if(session!=null)
            {
                request.getRequestDispatcher("CPWDForm.html").include(request, response);
            }
            else
            {
                out.println("Unauthorized Access Found");
                request.getRequestDispatcher("SignIn.html").include(request, response);
            }
    }
}