/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/CPWDProc")
public class CPWDProc extends HttpServlet 
{
        protected void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
         {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
        
            String opass=request.getParameter("opass");
            String npass=request.getParameter("npass");
            
            String url="jdbc:mysql://localhost:3306/obbs",user="Anirudh",pwd="OBBS@123@";
            
            HttpSession session=request.getSession(false);
            String uname=(String)session.getAttribute("username");
            
            if(session!=null)
            {
                try {
                        Class.forName("com.mysql.jdbc.Driver");
                        Connection conn=DriverManager.getConnection(url, user, pwd);
                        Statement stmt=conn.createStatement();
                        String query="select Password from users where User_Name='"+uname+"' ";
                        ResultSet rs=stmt.executeQuery(query);

                        while(rs.next())
                        {
                            if((rs.getString(1)).equals(opass))
                            {
                                String q="Update users set Password='"+npass+"' where User_Name='"+uname+"' ";
                                if(stmt.executeUpdate(q)>0){
                                    out.println("<h1>Password Updated Successfully</h1>");
                                    RequestDispatcher rd=request.getRequestDispatcher("SignIn.html");
                                    rd.include(request, response); 
                                }
                            }
                            else
                            {
                                out.println("<h3>Invalid Old Password<br><br>Pleae Try Again</h3>");
                                RequestDispatcher rd=request.getRequestDispatcher("CPWDForm.html");
                                rd.include(request, response);
                            }
                        }
                    }
                catch(Exception e){}
            }
            else
            {
                out.println("Unauthorized Access Found");
                request.getRequestDispatcher("SignIn.html").include(request, response);                
            }
            out.close();
        }
        protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
        {
            doGet(request,response);
        }
        
}


