

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class OrgRegProc extends HttpServlet 
{    
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String name=request.getParameter("name");
        String city=request.getParameter("city");
        String phNumber=request.getParameter("phoneNumber");
        String email=request.getParameter("email");
        String uname=request.getParameter("uname");
        int a=Integer.parseInt(request.getParameter("a"));
        int a1=Integer.parseInt(request.getParameter("a1"));
        int b=Integer.parseInt(request.getParameter("b"));
        int b1=Integer.parseInt(request.getParameter("b1"));
        int ab=Integer.parseInt(request.getParameter("ab"));
        int ab1=Integer.parseInt(request.getParameter("ab1"));
        int o=Integer.parseInt(request.getParameter("o"));
        int o1=Integer.parseInt(request.getParameter("o1"));
        
        String url="jdbc:mysql://localhost:3306/obbs",user="Anirudh",pwd="OBBS@123@";
        
        String query="insert into organisations values('"+name+"','"+city+"','"+phNumber+"','"+email+"','"+uname+"','"+a+"','"+a1+"','"+b+"','"+b1+"','"+ab+"','"+ab1+"','"+o+"','"+o1+"')";
        
        try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn=DriverManager.getConnection(url, user, pwd);
                Statement stmt=conn.createStatement();
                
                if(stmt.executeUpdate(query)>0)
                {
                    out.println("<h1>Successfully Registered as a Donor</h1><br><br>");
                    RequestDispatcher rd=request.getRequestDispatcher("Menu.html");
                    rd.include(request, response);
                }
                else
                {
                    out.println("<h3>Wrong Credintials<br><br>Pleae Try Again</h3>");
                    RequestDispatcher rd=request.getRequestDispatcher("OrgReg.html");
                    rd.include(request, response);
                }
            } catch (Exception e) {}
            out.close();
        }
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
    {
        doGet(request,response);
    }
} 

