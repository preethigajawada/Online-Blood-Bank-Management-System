

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class SignUpProc extends HttpServlet 
{    
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String name=request.getParameter("name");
        String uname=request.getParameter("uname");
        String pass=request.getParameter("pass");
        
        String url="jdbc:mysql://localhost:3306/obbs",user="Anirudh",pwd="OBBS@123@";
        
        String query="insert into users values('"+name+"','"+uname+"','"+pass+"')";
        
        String q="select * from users";
        
        try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn=DriverManager.getConnection(url, user, pwd);
                Statement stmt=conn.createStatement();
                
                ResultSet rs=stmt.executeQuery(q);
                
                while(rs.next()){ 
                    if(rs.getString(2).equals(uname)){
                                        out.println("<html><head></head><body onload=\"alert('hello')\"></body></html>");
                    //RequestDispatcher rd=request.getRequestDispatcher("SignUp.html");
                    //rd.include(request, response);
                    }
                    else{
                            if(stmt.executeUpdate(query)>0)
                            {
                                out.println("<h1>Successfull</h1><br><br>");
                                RequestDispatcher rd=request.getRequestDispatcher("index.html");
                                rd.include(request, response);
                            }
                }
            } }catch (Exception e) {}
            out.close();
        }
} 

