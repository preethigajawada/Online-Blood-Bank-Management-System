

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UDonorProc")
public class UDonorProc extends HttpServlet 
{    
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String name=request.getParameter("name");
        String email=request.getParameter("email");
        String city=request.getParameter("city");
        String bg=request.getParameter("bloodGroup");
        String ldd=request.getParameter("lastDonationDate");
        String gender=request.getParameter("gender");
        String phNumber=request.getParameter("phoneNumber");
        String weight=request.getParameter("weight");
        String dob=request.getParameter("birthDate");
        String uname=request.getParameter("uname");
        
        String url="jdbc:mysql://localhost:3306/obbs",user="Anirudh",pwd="OBBS@123@";
        
        String query="insert into donors values('"+name+"','"+email+"','"+city+"','"+bg+"','"+ldd+"','"+gender+"','"+phNumber+"','"+weight+"','"+dob+"','"+uname+"')";
        
        try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn=DriverManager.getConnection(url, user, pwd);
                Statement stmt=conn.createStatement();
                
                if(stmt.executeUpdate(query)>0)
                {
                    out.println("<h1>Successfull Registered as a Donor</h1><br><br>");
                    RequestDispatcher rd=request.getRequestDispatcher("Menu.html");
                    rd.include(request, response);
                }
                else
                {
                    out.println("<h3>Wrong Credintials<br><br>Pleae Try Again</h3>");
                    RequestDispatcher rd=request.getRequestDispatcher("DonorReg.html");
                    rd.include(request, response);
                }
            } catch (Exception e) {}
            out.close();
        }
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
    {
        doGet(request,response);
    }
} 

